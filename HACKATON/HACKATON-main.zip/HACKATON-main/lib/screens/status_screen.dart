import 'package:flutter/material.dart';
import '../main.dart';
import '../models/employee.dart';
import 'calculator_screen.dart';

class StatusScreen extends StatelessWidget {
  const StatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final employee = Employee(
      fullName: 'Иванов Иван',
      dealerCode: 'DC-123',
      position: 'Менеджер',
      level: 'Silver',
      currentPoints: 62,
      nextLevelPoints: 100,
      dealsCount: 15,
      volume: 27.5,
      bankShare: 35,
      annualBenefit: 312400,
    );

    final nextLevel = _getNextLevel(employee.level);
    final pointsToNext = employee.pointsToNextLevel;
    final progressPercent = employee.progressPercent;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Мой статус'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Бейдж уровня с градиентом
            _buildLevelBadge(employee.level),
            
            const SizedBox(height: 24),

            // Прогресс до следующего уровня
            _buildProgressCard(nextLevel, pointsToNext, progressPercent),
            
            const SizedBox(height: 24),

            // Финансовый прогноз
            _buildFinancialForecast(context),
            
            const SizedBox(height: 24),

            // Быстрые действия
            _buildQuickActions(context),
          ],
        ),
      ),
    );
  }

  Widget _buildLevelBadge(String level) {
    final gradient = _getLevelGradient(level);
    final icon = _getLevelIcon(level);

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: gradient.colors.first.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, size: 64, color: Colors.white),
          const SizedBox(height: 12),
          Text(
            level.toUpperCase(),
            style: const TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Ваш текущий уровень',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard(String nextLevel, int pointsToNext, double progressPercent) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Прогресс до следующего уровня',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: DealerApp.sberGreenLight,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    nextLevel,
                    style: const TextStyle(
                      color: DealerApp.sberGreen,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            
            // Прогресс-бар
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: progressPercent / 100,
                minHeight: 12,
                backgroundColor: Colors.grey.shade200,
              ),
            ),
            
            const SizedBox(height: 12),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Осталось $pointsToNext баллов',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 14,
                  ),
                ),
                Text(
                  '${progressPercent.toStringAsFixed(1)}%',
                  style: const TextStyle(
                    color: DealerApp.sberGreen,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialForecast(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: DealerApp.sberGreenLight,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.trending_up,
                    color: DealerApp.sberGreen,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Финансовый прогноз',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            
            _buildForecastItem(
              'Доход вырастет на',
              '180 000 ₽',
              Icons.attach_money,
              DealerApp.sberGreen,
            ),
            const Divider(height: 24),
            _buildForecastItem(
              'Экономия на ипотеке',
              '740 000 ₽',
              Icons.home,
              DealerApp.sberYellow,
            ),
            
            const SizedBox(height: 16),
            
            Text(
              'При переходе на Gold',
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildForecastItem(String label, String value, IconData icon, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: Colors.grey.shade700,
                fontSize: 14,
              ),
            ),
          ],
        ),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 56,
          child: ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CalculatorScreen()),
            ),
            icon: const Icon(Icons.rocket_launch),
            label: const Text('Как ускорить переход'),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 56,
          child: OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.info_outline),
            label: const Text('О программе лояльности'),
            style: OutlinedButton.styleFrom(
              backgroundColor: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  LinearGradient _getLevelGradient(String level) {
    switch (level) {
      case 'Silver':
        return const LinearGradient(
          colors: [Color(0xFFBDC3C7), Color(0xFF7F8C8D)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
      case 'Gold':
        return const LinearGradient(
          colors: [Color(0xFFF1C40F), Color(0xFFB7950B)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
      case 'Black':
        return const LinearGradient(
          colors: [Color(0xFF434343), Color(0xFF1F1F1F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
      default:
        return const LinearGradient(
          colors: [DealerApp.sberGreen, DealerApp.sberGreenDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
    }
  }

  IconData _getLevelIcon(String level) {
    switch (level) {
      case 'Silver':
        return Icons.stars;
      case 'Gold':
        return Icons.workspace_premium;
      case 'Black':
        return Icons.diamond;
      default:
        return Icons.star;
    }
  }

  String _getNextLevel(String level) {
    switch (level) {
      case 'Silver':
        return 'Gold';
      case 'Gold':
        return 'Black';
      default:
        return 'Platinum';
    }
  }
}
