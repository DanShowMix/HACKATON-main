import 'package:flutter/material.dart';
import '../main.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  double deals = 15;
  double volume = 27.5;
  double bankShare = 35;
  double products = 5;

  int get points =>
      (deals * 2).toInt() +
      volume.toInt() +
      (bankShare / 5).toInt() +
      products.toInt();

  String get level {
    if (points < 100) return 'Silver';
    if (points < 200) return 'Gold';
    return 'Black';
  }

  int get income => points * 5000;
  
  int get mortgageSavings => points * 12000;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Сценарный калькулятор'),
      ),
      body: Column(
        children: [
          // Карточка текущего статуса
          _buildCurrentStatusCard(),
          
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Заголовок секции
                  Text(
                    'Параметры для расчёта',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Ползунки
                  _buildSlider(
                    'Сделки (шт)',
                    deals,
                    0,
                    50,
                    (v) => setState(() => deals = v),
                    Icons.shopping_cart,
                  ),
                  _buildSlider(
                    'Объём (млн ₽)',
                    volume,
                    0,
                    100,
                    (v) => setState(() => volume = v),
                    Icons.attach_money,
                  ),
                  _buildSlider(
                    'Доля банка (%)',
                    bankShare,
                    0,
                    100,
                    (v) => setState(() => bankShare = v),
                    Icons.pie_chart,
                  ),
                  _buildSlider(
                    'Доп. продукты',
                    products,
                    0,
                    20,
                    (v) => setState(() => products = v),
                    Icons.add_circle,
                  ),

                  const SizedBox(height: 24),

                  // Результаты расчёта
                  _buildResultsCard(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentStatusCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [DealerApp.sberGreen, DealerApp.sberGreenDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          const Text(
            'Текущий статус',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                _getLevelIcon(level),
                color: Colors.white,
                size: 32,
              ),
              const SizedBox(width: 12),
              Text(
                level,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSlider(
    String label,
    double value,
    double min,
    double max,
    Function(double) onChanged,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: DealerApp.sberGreenLight,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(icon, color: DealerApp.sberGreen, size: 18),
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: DealerApp.sberGreenLight,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    value.toInt().toString(),
                    style: const TextStyle(
                      color: DealerApp.sberGreen,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SliderTheme(
              data: SliderThemeData(
                activeTrackColor: DealerApp.sberGreen,
                inactiveTrackColor: Colors.grey.shade300,
                thumbColor: DealerApp.sberGreen,
                overlayColor: DealerApp.sberGreen.withOpacity(0.2),
                trackHeight: 6,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12),
              ),
              child: Slider(
                value: value,
                min: min,
                max: max,
                divisions: (max - min).toInt(),
                onChanged: onChanged,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultsCard() {
    final newLevel = level;
    final newPoints = points;
    final newIncome = income;
    final newSavings = mortgageSavings;

    return Card(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              DealerApp.sberGreenLight,
              Colors.white,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.analytics, color: DealerApp.sberGreen),
                const SizedBox(width: 8),
                const Text(
                  'Результаты расчёта',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            
            _buildResultRow(
              'Новый рейтинг',
              '$newPoints баллов',
              Icons.star_rounded,
              DealerApp.sberGreen,
            ),
            const SizedBox(height: 12),
            _buildResultRow(
              'Новый уровень',
              newLevel,
              Icons.workspace_premium,
              DealerApp.sberYellow,
              isBadge: true,
            ),
            const SizedBox(height: 12),
            _buildResultRow(
              'Прогноз дохода',
              '${newIncome.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]} ')} ₽/год',
              Icons.attach_money,
              DealerApp.sberGreen,
            ),
            const SizedBox(height: 12),
            _buildResultRow(
              'Экономия на ипотеке',
              '${newSavings.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]} ')} ₽',
              Icons.home,
              Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultRow(
    String label,
    String value,
    IconData icon,
    Color color, {
    bool isBadge = false,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: Colors.grey.shade700,
              fontSize: 14,
            ),
          ),
        ),
        if (isBadge)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              value,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          )
        else
          Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
      ],
    );
  }

  IconData _getLevelIcon(String level) {
    switch (level) {
      case 'Silver':
        return Icons.stars;
      case 'Gold':
        return Icons.workspace_premium;
      case 'Black':
        return Icons.diamond;
      default:
        return Icons.star;
    }
  }
}
