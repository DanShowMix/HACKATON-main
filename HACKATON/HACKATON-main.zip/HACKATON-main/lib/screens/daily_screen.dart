import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../main.dart';
import 'rating_screen.dart';

class DailyScreen extends StatefulWidget {
  const DailyScreen({super.key});

  @override
  State<DailyScreen> createState() => _DailyScreenState();
}

class _DailyScreenState extends State<DailyScreen> {
  final _formKey = GlobalKey<FormState>();

  final _dealsController = TextEditingController();
  final _volumeController = TextEditingController();
  final _productsController = TextEditingController();

  Map<String, dynamic>? _todayData;

  @override
  void dispose() {
    _dealsController.dispose();
    _volumeController.dispose();
    _productsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Результаты дня'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download_outlined),
            onPressed: _exportData,
            tooltip: 'Выгрузить отчёт',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Дата
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: DealerApp.sberGreenLight,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.calendar_today,
                        color: DealerApp.sberGreen,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      _getTodayDate(),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            if (_todayData == null) ...[
              // Форма ввода
              const Text(
                'Внесите результаты за сегодня',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Form(
                  key: _formKey,
                  child: ListView(
                    children: [
                      _buildInputField(
                        'Оформлено сделок',
                        'шт',
                        _dealsController,
                        Icons.shopping_cart,
                      ),
                      const SizedBox(height: 16),
                      _buildInputField(
                        'Объём кредитов',
                        'млн ₽',
                        _volumeController,
                        Icons.attach_money,
                      ),
                      const SizedBox(height: 16),
                      _buildInputField(
                        'Доп. продукты',
                        'шт',
                        _productsController,
                        Icons.add_circle,
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        height: 56,
                        child: ElevatedButton.icon(
                          onPressed: _submitData,
                          icon: const Icon(Icons.check),
                          label: const Text('Сохранить результаты'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ] else ...[
              // Отображение сохранённых данных
              Expanded(
                child: ListView(
                  children: [
                    _buildResultCard(
                      'Сделки',
                      '${_todayData!['deals']} шт',
                      Icons.shopping_cart,
                      DealerApp.sberGreen,
                    ),
                    const SizedBox(height: 12),
                    _buildResultCard(
                      'Объём кредитов',
                      '${_todayData!['volume']} млн ₽',
                      Icons.attach_money,
                      DealerApp.sberYellow,
                    ),
                    const SizedBox(height: 12),
                    _buildResultCard(
                      'Доп. продукты',
                      '${_todayData!['products']} шт',
                      Icons.add_circle,
                      Colors.blue,
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      height: 56,
                      child: OutlinedButton.icon(
                        onPressed: () => setState(() => _todayData = null),
                        icon: const Icon(Icons.edit),
                        label: const Text('Изменить данные'),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 16),

            // Кнопка детализации
            SizedBox(
              height: 56,
              child: TextButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RatingScreen()),
                ),
                icon: const Icon(Icons.analytics),
                label: const Text('Детализация рейтинга'),
                style: TextButton.styleFrom(
                  backgroundColor: DealerApp.sberGreenLight,
                  foregroundColor: DealerApp.sberGreen,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField(
    String label,
    String suffix,
    TextEditingController controller,
    IconData icon,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: DealerApp.sberGreen, size: 20),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: controller,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: InputDecoration(
                labelText: 'Введите значение',
                suffixText: suffix,
                suffixStyle: TextStyle(
                  color: Colors.grey.shade600,
                  fontWeight: FontWeight.w500,
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Введите значение';
                }
                if (int.tryParse(value) == null) {
                  return 'Только целые числа';
                }
                return null;
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.check_circle, color: color, size: 28),
          ],
        ),
      ),
    );
  }

  String _getTodayDate() {
    final now = DateTime.now();
    final months = [
      'янв', 'фев', 'мар', 'апр', 'мая', 'июн',
      'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'
    ];
    return '${now.day} ${months[now.month - 1]} ${now.year}';
  }

  void _submitData() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _todayData = {
          'deals': _dealsController.text,
          'volume': _volumeController.text,
          'products': _productsController.text,
        };
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 12),
              Text('Данные сохранены'),
            ],
          ),
          backgroundColor: DealerApp.sberGreen,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  void _exportData() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.download, color: Colors.white),
            SizedBox(width: 12),
            Text('Отчёт выгружен в CSV'),
          ],
        ),
        backgroundColor: DealerApp.sberGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
