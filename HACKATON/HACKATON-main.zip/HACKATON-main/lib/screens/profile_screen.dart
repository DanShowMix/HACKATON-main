import 'package:flutter/material.dart';
import '../main.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final employee = {
      'name': 'Иванов Иван Иванович',
      'dealerCode': 'DC-123',
      'position': 'Менеджер по продажам',
      'level': 'Silver',
      'phone': '+7 (999) 123-45-67',
      'email': 'ivanov@dealer.ru',
      'regDate': '15.03.2024',
      'inProgram': '2 года',
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('Профиль'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {},
            tooltip: 'Настройки',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Аватар и имя
            _buildProfileHeader(employee),
            
            const SizedBox(height: 24),

            // Информация о сотруднике
            _buildInfoCard(employee),
            
            const SizedBox(height: 24),

            // Кнопка Sber ID
            _buildSberIdButton(),
            
            const SizedBox(height: 12),

            // Кнопка поддержки
            _buildSupportButton(context),
            
            const SizedBox(height: 12),

            // Кнопка выхода
            _buildLogoutButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader(Map<String, dynamic> employee) {
    final initials = _getInitials(employee['name'] as String);
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Аватар
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [DealerApp.sberGreen, DealerApp.sberGreenDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  initials,
                  style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            // Имя
            Text(
              employee['name'] as String,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            
            // Должность и код ДЦ
            Text(
              '${employee['position']} | ДЦ: ${employee['dealerCode']}',
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            
            // Бейдж уровня
            _buildLevelBadge(employee['level'] as String),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(Map<String, dynamic> employee) {
    return Card(
      child: Column(
        children: [
          _buildInfoTile(
            Icons.badge_outlined,
            'Код ДЦ',
            employee['dealerCode'] as String,
          ),
          const Divider(height: 1),
          _buildInfoTile(
            Icons.work_outline,
            'Должность',
            employee['position'] as String,
          ),
          const Divider(height: 1),
          _buildInfoTile(
            Icons.phone_outlined,
            'Телефон',
            employee['phone'] as String,
          ),
          const Divider(height: 1),
          _buildInfoTile(
            Icons.email_outlined,
            'Почта',
            employee['email'] as String,
          ),
          const Divider(height: 1),
          _buildInfoTile(
            Icons.calendar_today_outlined,
            'В программе',
            employee['inProgram'] as String,
          ),
          const Divider(height: 1),
          _buildInfoTile(
            Icons.event_outlined,
            'Дата регистрации',
            employee['regDate'] as String,
          ),
        ],
      ),
    );
  }

  Widget _buildLevelBadge(String level) {
    final gradient = _getLevelGradient(level);
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _getLevelIcon(level),
            color: Colors.white,
            size: 18,
          ),
          const SizedBox(width: 8),
          Text(
            'Уровень: $level',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSberIdButton() {
    return SizedBox(
      height: 56,
      child: OutlinedButton.icon(
        onPressed: () {
          // Тут будет интеграция с Sber ID
        },
        icon: const Icon(Icons.fingerprint),
        label: const Text('Войти через Sber ID'),
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.white,
        ),
      ),
    );
  }

  Widget _buildSupportButton(BuildContext context) {
    return SizedBox(
      height: 56,
      child: ElevatedButton.icon(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('💬 Чат с менеджером'),
              backgroundColor: DealerApp.sberGreen,
            ),
          );
        },
        icon: const Icon(Icons.support_agent),
        label: const Text('Служба поддержки'),
        style: ElevatedButton.styleFrom(
          backgroundColor: DealerApp.sberGreen,
        ),
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    return SizedBox(
      height: 56,
      child: TextButton.icon(
        onPressed: () => _showLogoutDialog(context),
        icon: const Icon(Icons.logout, color: Colors.red),
        label: const Text('Выйти', style: TextStyle(color: Colors.red)),
      ),
    );
  }

  Widget _buildInfoTile(IconData icon, String label, String value) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: DealerApp.sberGreenLight,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: DealerApp.sberGreen, size: 20),
      ),
      title: Text(
        label,
        style: TextStyle(
          fontSize: 13,
          color: Colors.grey.shade600,
        ),
      ),
      subtitle: Text(
        value,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w500,
        ),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    );
  }

  String _getInitials(String fullName) {
    final parts = fullName.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}';
    }
    return parts[0].substring(0, 2).toUpperCase();
  }

  LinearGradient _getLevelGradient(String level) {
    switch (level) {
      case 'Silver':
        return const LinearGradient(
          colors: [Color(0xFFBDC3C7), Color(0xFF7F8C8D)],
        );
      case 'Gold':
        return const LinearGradient(
          colors: [Color(0xFFF1C40F), Color(0xFFB7950B)],
        );
      case 'Black':
        return const LinearGradient(
          colors: [Color(0xFF434343), Color(0xFF1F1F1F)],
        );
      default:
        return const LinearGradient(
          colors: [DealerApp.sberGreen, DealerApp.sberGreenDark],
        );
    }
  }

  IconData _getLevelIcon(String level) {
    switch (level) {
      case 'Silver':
        return Icons.stars;
      case 'Gold':
        return Icons.workspace_premium;
      case 'Black':
        return Icons.diamond;
      default:
        return Icons.star;
    }
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.warning_amber, color: Colors.orange.shade700),
            const SizedBox(width: 8),
            const Text('Выход'),
          ],
        ),
        content: const Text('Вы уверены, что хотите выйти из приложения?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Выход из системы'),
                  backgroundColor: DealerApp.sberGreen,
                ),
              );
            },
            child: const Text('Выйти', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
