import 'package:flutter/material.dart';
import '../main.dart';
import 'calculator_screen.dart';

class RatingScreen extends StatelessWidget {
  const RatingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ratingData = {
      'Объём': {
        'points': 32,
        'info': '1 млн ₽ = 1 балл',
        'tip': 'Увеличьте сумму кредитов',
        'icon': Icons.show_chart,
      },
      'Сделки': {
        'points': 18,
        'info': '1 сделка = 2 балла',
        'tip': 'Оформляйте больше заявок',
        'icon': Icons.shopping_bag,
      },
      'Доля банка': {
        'points': 12,
        'info': '1% доли = 0.5 балла',
        'tip': 'Предлагайте продукты банка чаще',
        'icon': Icons.pie_chart,
      },
    };

    final totalPoints = 62;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Детализация рейтинга'),
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: () => _showInfoDialog(context),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Общая сумма баллов
            _buildTotalPointsCard(totalPoints),
            
            const SizedBox(height: 20),

            // Заголовок секции
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Показатели рейтинга',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey.shade700,
                ),
              ),
            ),
            
            const SizedBox(height: 12),

            // Детализация по показателям
            Expanded(
              child: ListView(
                children: ratingData.entries.map((entry) {
                  return _buildRatingCard(
                    entry.key,
                    entry.value['points'] as int,
                    entry.value['info'] as String,
                    entry.value['tip'] as String,
                    entry.value['icon'] as IconData,
                  );
                }).toList(),
              ),
            ),

            // Кнопка "Смоделировать рост"
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CalculatorScreen()),
                ),
                icon: const Icon(Icons.trending_up),
                label: const Text('Смоделировать рост'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalPointsCard(int totalPoints) {
    return Card(
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [DealerApp.sberGreen, DealerApp.sberGreenDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            const Text(
              'Ваш рейтинг',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.star_rounded,
                  color: Colors.white,
                  size: 40,
                ),
                const SizedBox(width: 12),
                Text(
                  '$totalPoints баллов',
                  style: const TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRatingCard(
    String title,
    int points,
    String info,
    String tip,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: DealerApp.sberGreenLight,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: DealerApp.sberGreen),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: DealerApp.sberGreenLight,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '$points балл.',
            style: const TextStyle(
              color: DealerApp.sberGreen,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.calculate,
                      size: 18,
                      color: DealerApp.sberGreen,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Как рассчитывается',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            info,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                Row(
                  children: [
                    const Icon(
                      Icons.lightbulb,
                      size: 18,
                      color: DealerApp.sberYellow,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Как увеличить',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            tip,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showInfoDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: DealerApp.sberGreen),
            const SizedBox(width: 8),
            const Text('Как считается рейтинг'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Рейтинг рассчитывается ежедневно на основе:',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            _buildInfoItem('Объём профинансированных сделок', Icons.show_chart),
            _buildInfoItem('Количество сделок', Icons.shopping_bag),
            _buildInfoItem('Доля банка в портфеле дилера', Icons.pie_chart),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Понятно'),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String text, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 18, color: DealerApp.sberGreen),
          const SizedBox(width: 8),
          Text(text),
        ],
      ),
    );
  }
}
